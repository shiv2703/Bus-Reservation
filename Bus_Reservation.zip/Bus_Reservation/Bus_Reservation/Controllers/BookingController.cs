﻿using Bus_Reservation.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Bus_Reservation.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        public busReservationcontext _context { get; }

        public BookingController(busReservationcontext context)
        {
            _context = context;
        }   
    }
}
