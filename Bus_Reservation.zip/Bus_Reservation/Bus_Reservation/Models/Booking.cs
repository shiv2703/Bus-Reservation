﻿using System.ComponentModel.DataAnnotations;

namespace Bus_Reservation.Models
{
    public class Booking
    {
        [Key]
        public int BookingId { get; set; }

        [Required(ErrorMessage = "cost is required")]
        [Display(Name = "cost")]
        public int cost { get; set; }

        public int Userid { get; set; }

        public string seatNumber { get; set; }
    }
}
